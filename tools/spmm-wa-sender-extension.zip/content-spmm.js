function notifyReady() {
  window.postMessage({ type: 'SPMM_WA_EXTENSION_READY' }, '*');

  if (!document.getElementById('spmm-wa-extension-ready-badge')) {
    const badge = document.createElement('div');
    badge.id = 'spmm-wa-extension-ready-badge';
    badge.textContent = 'SPMM WA Extension aktif';
    badge.style.cssText = 'position:fixed;right:16px;bottom:16px;z-index:999999;background:#0891b2;color:white;padding:10px 14px;border-radius:999px;font:700 12px Arial,sans-serif;box-shadow:0 10px 25px rgba(15,23,42,.18);';
    document.documentElement.appendChild(badge);
  }
}

notifyReady();
setTimeout(notifyReady, 800);
setTimeout(notifyReady, 2500);

window.addEventListener('message', (event) => {
  if (event.source !== window) return;

  const message = event.data || {};
  if (message.type !== 'SPMM_WA_EXTENSION_START' || !message.queueUrl) return;

  chrome.runtime.sendMessage({
    type: 'SPMM_START_QUEUE',
    queueUrl: message.queueUrl,
  }, (response) => {
    const lastError = chrome.runtime.lastError?.message || null;

    window.postMessage({
      type: 'SPMM_WA_EXTENSION_RESPONSE',
      ok: Boolean(response?.ok) && !lastError,
      error: lastError || response?.error || null,
    }, '*');
  });
});