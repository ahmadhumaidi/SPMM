async function refresh() {
  chrome.runtime.sendMessage({ type: 'SPMM_GET_STATE' }, (response) => {
    const status = document.getElementById('status');
    const state = response?.state;

    if (!state) {
      status.textContent = 'Belum ada antrean aktif.';
      return;
    }

    status.innerHTML = `Broadcast: <strong>${state.broadcastName || '-'}</strong><br>Progress: ${Math.min(state.index + 1, state.recipients?.length || 0)} / ${state.recipients?.length || 0}<br>Status: ${state.running ? 'Berjalan' : 'Berhenti/Selesai'}`;
  });
}

document.getElementById('refresh').addEventListener('click', refresh);
document.getElementById('stop').addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'SPMM_STOP_QUEUE' }, refresh);
});
refresh();