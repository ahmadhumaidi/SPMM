const STATE_KEY = 'spmmWaSenderState';

async function getState() {
  return (await chrome.storage.local.get(STATE_KEY))[STATE_KEY] || null;
}

async function setState(state) {
  await chrome.storage.local.set({ [STATE_KEY]: state });
}

async function clearState() {
  await chrome.storage.local.remove(STATE_KEY);
}

async function postSignedUrl(url) {
  if (!url) return false;

  const response = await fetch(url, {
    method: 'POST',
    headers: { Accept: 'application/json' },
  });

  return response.ok;
}

async function fetchQueue(queueUrl) {
  const response = await fetch(queueUrl, { headers: { Accept: 'application/json' } });

  if (!response.ok) {
    throw new Error(`Gagal mengambil antrean SPMM (${response.status})`);
  }

  return response.json();
}

async function openCurrentRecipient() {
  const state = await getState();

  if (!state?.running) return;

  const recipient = state.recipients[state.index];
  if (!recipient) {
    await setState({ ...state, running: false, finishedAt: new Date().toISOString() });
    chrome.notifications?.create?.({
      type: 'basic',
      iconUrl: 'icon-128.png',
      title: 'SPMM WA Sender',
      message: 'Semua antrean selesai diproses.',
    });
    return;
  }

  const tabs = await chrome.tabs.query({ url: 'https://web.whatsapp.com/*' });
  let tab = tabs.find((candidate) => candidate.id === state.whatsappTabId) || tabs[0];

  if (tab?.id) {
    await chrome.tabs.update(tab.id, { url: recipient.web_url, active: true });
    await setState({ ...state, whatsappTabId: tab.id, lastOpenedAt: new Date().toISOString() });
  } else {
    tab = await chrome.tabs.create({ url: recipient.web_url, active: true });
    await setState({ ...state, whatsappTabId: tab.id, lastOpenedAt: new Date().toISOString() });
  }
}

async function startQueue(queueUrl) {
  const payload = await fetchQueue(queueUrl);
  const recipients = payload.recipients || [];

  if (recipients.length === 0) {
    throw new Error('Tidak ada penerima queued di broadcast ini.');
  }

  await setState({
    queueUrl,
    broadcastId: payload.broadcast_id,
    broadcastName: payload.broadcast_name,
    intervalSeconds: Math.max(30, Number(payload.interval_seconds || 45)),
    loadSeconds: Math.max(12, Number(payload.load_seconds || 16)),
    recipients,
    index: 0,
    running: true,
    startedAt: new Date().toISOString(),
  });

  await openCurrentRecipient();
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    if (message?.type === 'SPMM_START_QUEUE') {
      await startQueue(message.queueUrl);
      sendResponse({ ok: true });
      return;
    }

    if (message?.type === 'SPMM_GET_STATE') {
      sendResponse({ ok: true, state: await getState() });
      return;
    }

    if (message?.type === 'SPMM_STOP_QUEUE') {
      const state = await getState();
      if (state) await setState({ ...state, running: false, stoppedAt: new Date().toISOString() });
      sendResponse({ ok: true });
      return;
    }

    if (message?.type === 'SPMM_RECIPIENT_SENT') {
      const state = await getState();
      if (!state?.running) {
        sendResponse({ ok: false, error: 'Runner tidak aktif.' });
        return;
      }

      const recipient = state.recipients[state.index];
      if (!recipient) {
        sendResponse({ ok: false, error: 'Penerima tidak ditemukan.' });
        return;
      }

      await postSignedUrl(recipient.mark_sent_url);
      const nextIndex = state.index + 1;
      await setState({ ...state, index: nextIndex, lastSentAt: new Date().toISOString() });
      sendResponse({ ok: true, nextIndex });

      if (nextIndex < state.recipients.length) {
        setTimeout(openCurrentRecipient, Math.max(30, state.intervalSeconds) * 1000);
      } else {
        await setState({ ...state, index: nextIndex, running: false, finishedAt: new Date().toISOString() });
      }
      return;
    }

    sendResponse({ ok: false, error: 'Unknown message.' });
  })().catch((error) => {
    sendResponse({ ok: false, error: error.message || String(error) });
  });

  return true;
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status !== 'complete' || !tab.url?.startsWith('https://web.whatsapp.com/')) return;

  (async () => {
    const state = await getState();
    if (!state?.running || state.whatsappTabId !== tabId) return;

    const recipient = state.recipients[state.index];
    if (!recipient) return;

    setTimeout(() => {
      chrome.tabs.sendMessage(tabId, {
        type: 'SPMM_SEND_CURRENT',
        recipient,
        index: state.index,
        total: state.recipients.length,
      }).catch(() => undefined);
    }, Math.max(12, state.loadSeconds || 16) * 1000);
  })();
});