function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function visible(element) {
  if (!element) return false;
  const rect = element.getBoundingClientRect();
  return rect.width > 0 && rect.height > 0;
}

function findSendButton() {
  const ariaButtons = Array.from(document.querySelectorAll('button[aria-label], div[role="button"][aria-label]'));
  const byAria = ariaButtons.find((button) => /send|kirim/i.test(button.getAttribute('aria-label') || '') && visible(button));
  if (byAria) return byAria;

  const icon = document.querySelector('span[data-icon="send"]');
  if (icon) return icon.closest('button, div[role="button"]');

  return null;
}

async function clickSendWhenReady() {
  for (let attempt = 1; attempt <= 30; attempt += 1) {
    const button = findSendButton();
    if (button) {
      button.click();
      return true;
    }

    await sleep(1000);
  }

  return false;
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type !== 'SPMM_SEND_CURRENT') return false;

  (async () => {
    const recipient = message.recipient || {};
    console.log(`[SPMM WA Sender] Mengirim ${message.index + 1}/${message.total}: ${recipient.name || recipient.phone}`);

    const sent = await clickSendWhenReady();
    if (!sent) {
      sendResponse({ ok: false, error: 'Tombol kirim WhatsApp tidak ditemukan.' });
      return;
    }

    await sleep(1800);
    chrome.runtime.sendMessage({ type: 'SPMM_RECIPIENT_SENT' }, (response) => {
      sendResponse(response || { ok: true });
    });
  })().catch((error) => {
    sendResponse({ ok: false, error: error.message || String(error) });
  });

  return true;
});